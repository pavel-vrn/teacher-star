<?php 
$layout = of_get_option('home_layout');

if( $layout == 'layout1'){
include('layout1.php');
}elseif( $layout == 'layout2'){
include('layout2.php');
}elseif( $layout == 'layout3'){
include('layout3.php');
}else{
include('layout3.php');
}

 ?>