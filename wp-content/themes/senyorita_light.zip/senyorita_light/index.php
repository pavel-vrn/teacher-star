<?php get_header(); ?>

<?php
$x = of_get_option('enablewelcome');
if($x == 1){
include('welcome.php');
}
?>


<?php
$x = of_get_option('check_slider');
if($x == 1){
include('slider.php');
}
?>





<?php include('layout.php'); ?>



<?php get_footer(); ?>