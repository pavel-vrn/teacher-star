<!--Featured Items-->
<div class="margin-2">

<div class="spacing-20"></div>


<?php for( $x = 1; $x <= 4; $x++){ ?>


<div class="one-fourth features">
<img src="<?php bloginfo( 'template_directory' ); ?>/images/icons/<?php echo of_get_option('featured_icon'.$x); ?>" />
<h2><?php echo of_get_option('servicetitle'.$x); ?></h2>
<p><?php echo of_get_option('servicedesc'.$x); ?></p>
</div>


<?php } ?>


<div class="clr"></div>
</div>
<!--Featured Items-->