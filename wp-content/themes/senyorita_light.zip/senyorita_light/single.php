<?php get_header(); ?>







<!-- Margin -->
<div class="margin-2">

<div class="spacing-40"></div>

<!-- Single Page Container-->
	<div id="single">
		
		<h2 class="entry-header"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>
		
		<?php include('meta-data-2.php'); ?>
		
	
		<div class="entry">
		
		<?php 
						$my_postid = get_page( $page_id );//This is page id or post id
						$content_post = get_post($my_postid);
						$content = $content_post->post_content;
						$content = apply_filters('the_content', $content);
						//$content = str_replace(']]>', ']]>', $content);
						echo $content; 
						?>
		</div>
	
	<div class="spacing-30"></div>
	
		<?php comments_template(); ?>
		
	</div>
<!-- Single Page Container-->


<!-- Margin -->
<div id="widget-container">
	<?php
	if ( !function_exists('dynamic_sidebar')
      	|| !dynamic_sidebar(2) ) : 
    endif;
							
	?>
</div>
<!-- Margin -->

<div class="clr"></div>
<div class="spacing-20"></div>
</div>




<?php get_footer(); ?>