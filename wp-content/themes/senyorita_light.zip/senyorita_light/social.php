<?php if( of_get_option('check_socials') ){ ?>

	<div id="footer-social">
		<ul>
		<li><a href="<?php echo of_get_option('tweet'); ?>" target="_blank"><img src="<?php bloginfo( 'template_directory' ); ?>/images/icons/twitter.png" /></a></li>
		
		<li><a href="<?php echo of_get_option('fb'); ?>" target="_blank"><img src="<?php bloginfo( 'template_directory' ); ?>/images/icons/facebook.png" /></a></li>
		
		<li><a href="<?php echo of_get_option('youtube'); ?>" target="_blank"><img src="<?php bloginfo( 'template_directory' ); ?>/images/icons/youtube.png" /></a></li>
		
		<li><a href="<?php echo of_get_option('linked'); ?>" target="_blank"><img src="<?php bloginfo( 'template_directory' ); ?>/images/icons/LinkedIn.png" /></a></li>
		</ul>
	</div>
	
<?php } ?>