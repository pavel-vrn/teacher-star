<!--Welcome Message-->
<div id="welcome">
<?php echo of_get_option('welcome_msg'); ?>
</div>
<!--Welcome Message-->