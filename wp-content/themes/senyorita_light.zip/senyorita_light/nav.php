<?php if( has_nav_menu('header_menu') ){ ?>

<?php wp_nav_menu( array(
				   'theme_location' => 'header_menu',
				   'container' => 'false',
				   'items_wrap' => '<ul id="nav">%3$s</ul>',
)); ?>


<?php }else{ ?>



		<ul id="nav">
			<li><a href="<?php echo home_url( '/' ); ?>">home</a></li>
				<?php
				$clean_page_list = wp_list_pages('echo=0&title_li=&sort_column=menu_order');
				$clean_page_list = preg_replace('/title=\"(.*?)\"/','',$clean_page_list);
				echo $clean_page_list;
				?>
		</ul>
		
		
		
<?php } ?>