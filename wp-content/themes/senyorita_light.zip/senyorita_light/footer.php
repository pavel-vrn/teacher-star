

<?php if(is_active_sidebar(1) ){ ?>

<!--Footer Widget-->
<div id="footer-widget">
<div id="footer-widget-container">

		<?php
			if ( !function_exists('dynamic_sidebar')
      					|| !dynamic_sidebar(1) ) : 
     						endif;
							
	 		?>

</div>
<div class="clr"></div>
</div>
<!--Footer Widget-->

<?php } ?>

<!--Footer-->
<div class="full2">
<div class="margin">

	<div id="footer-info"><?php echo of_get_option('footerinfo'); ?></div>
	
	<?php include('social.php'); ?>
	
</div>
<div class="clr"></div>
</div>
<!--Footer-->

<div class="credit">Theme Provided by <a href="http://joolu.com" target="_blank">Joolu Portfolio Theme</a></div>

<?php wp_footer(); ?>


<!-- Load jQuery and the plug-in -->
    <script src="<?php bloginfo( 'template_directory' ); ?>/js/basic-jquery-slider.js"></script>
    
    <!--  Attach the plug-in to the slider parent element and adjust the settings as required -->
    <script>
      $(document).ready(function() {
        
        $('#slider').bjqs({
          'animation' : '<?php echo of_get_option('slider_animation'); ?>',
          'width' : 960,
          'height' : 400
        });
        
      });
    </script>

</body>
</html>