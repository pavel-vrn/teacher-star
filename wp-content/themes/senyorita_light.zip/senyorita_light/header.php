<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php wp_head(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<link href="<?php bloginfo( 'stylesheet_url' ); ?>" type="text/css" media="all" rel="stylesheet" />
<script type='text/javascript' src='<?php bloginfo( 'template_directory' ); ?>/js/jquery-1.6.2.min.js'></script>

<!--Slider-->
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ); ?>/js/jquery-1.4.2.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ); ?>/js/coin-slider.min.js"></script>
<link rel="stylesheet" href="<?php bloginfo( 'template_directory' ); ?>/css/coin-slider-styles.css" type="text/css" />

<script type="text/javascript">
    $(document).ready(function() {
        $('#coin-slider').coinslider({ 
		width: 960,
		height: 300,
		navigation: true, 
		delay: 5000,
		sDelay: 70,
		
		
		});
    });
</script>


<!--Slider-->

<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 */
	global $page, $paged;

	wp_title( '&lsaquo;&lsaquo;', true, 'right' );

	// Add the blog name.
	bloginfo( 'name' );

	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " &lsaquo;&lsaquo; $site_description";

	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 )
		echo ' &lsaquo;&lsaquo; ' . sprintf( __( 'Page %s', 'supportpress' ), max( $paged, $page ) );

	?></title>
</head>

<body>

<div class="spacing-30"></div>

<div class="spacing-header"></div>

<!--Header-->
<div class="full2">
<div class="margin-2">

<div id="logo">
<a href="<?php echo home_url( '/' ); ?>">
<img src="<?php echo of_get_option('logo_upload'); ?>" />
</a>
</div>

	<?php include('nav.php'); ?>
		
</div>
<div class="clr"></div>
</div>
<!--Header-->