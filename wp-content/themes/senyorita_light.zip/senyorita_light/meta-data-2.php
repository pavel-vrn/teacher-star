
<ul class="entry-meta clr">

 <?php while ( have_posts() ) : the_post(); ?>

	<li>posted by: <?php the_author_posts_link(); ?></li>
	
	<li><span>//</span></li>
	<li>posted on: <?php the_time('F j Y') ?></li>
	
	<li><span>//</span></li>
	<li>With: <?php comments_number() ?></li>
	<?php endwhile; ?>
	<div class="clr"></div>
	
</ul>