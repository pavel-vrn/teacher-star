<ul class="entry-meta clr">

	<li>posted by: <?php the_author_posts_link(); ?></li>
	
	<li><span>//</span></li>
	<li>posted on: <?php the_time('F j Y') ?></li>
	
	<li><span>//</span></li>
	<li>With: <?php comments_number() ?></li>
	<div class="clr"></div>
	
</ul>