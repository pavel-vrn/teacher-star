<?php 
/* Template Name: Portfolio */
	get_header();
?>





<!-- Margin -->
<div class="margin-2">

<div class="spacing-40"></div>

<div class="one-fourth" id="portfolio-desc">
<span><?php the_title(); ?></span>

<?php 
						$my_postid = get_page( $page_id );//This is page id or post id
						$content_post = get_post($my_postid);
						$content = $content_post->post_content;
						$content = apply_filters('the_content', $content);
						//$content = str_replace(']]>', ']]>', $content);
						echo $content; 
						?>
</div>



<div id="portfolio-container">

    <?php query_posts('post_type=portfolio&posts_per_page=9&paged='.$paged);
	while ( have_posts() ) : the_post();
	?>
	
<div class="one-fourth portfolio-box">
<?php if(has_post_thumbnail()) { ?>
<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('index-recent',array('title' => "") ); ?></a>
<?php }else{ ?>
<img src="<?php bloginfo( 'template_directory' ); ?>/images/noimage.png" height="100" />
<?php } ?>
<h4><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h4>
<p><?php content('8'); ?></p>
</div>
	<?php endwhile; ?>

		<?php pagination(); ?>

</div>
	

<div class="clr"></div>
<div class="spacing-20"></div>
</div>




<?php get_footer(); ?>