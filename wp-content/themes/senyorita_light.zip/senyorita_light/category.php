<?php get_header(); ?>


<!-- Page Header-->
<div class="margin-2" id="page-header">

<div id="page-header-con">
	<h2>Blog Archives</h2>
</div>

<form>
<input type="button" class="header-submit" />
<input type="text" name="s" class="header-search" onfocus="if( this.value == 'Search...' ) this.value = '';" 

                    onblur="if( this.value == '' ) this.value = 'Search...';" 

                    value="Search..." 
 />
</form>

<div class="clr"></div>
</div>
<!-- Page Header-->





<!-- Margin -->
<div class="margin-2">

<div class="spacing-40"></div>

<!-- Blog Container-->
	<div id="blog-container">
	

   		 <?php
			$cat_ID = get_query_var('cat');
			query_posts( 'paged='.$paged.'&posts_per_page=10&order=DESC'.'&cat='.$cat_ID);
				while ( have_posts() ) : the_post();
			?>
	
	
		<div class="blog-one-col">
		<?php 
		if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
		 the_post_thumbnail('blog-post',array('title' => "") );
			} 
		?>
		<h2><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>
		
		<?php include('meta-data.php'); ?>
		
		<p><?php content('30'); ?></p>
		</div>
		
		<?php endwhile; ?>
		
	
	</div>
<!-- Blog Container-->


<!-- Margin -->
<div id="widget-container">
<?php
			if ( !function_exists('dynamic_sidebar')
      					|| !dynamic_sidebar(2) ) : 
     						endif;
							
	 		?>
</div>
<!-- Margin -->

<div class="clr"></div>
<div class="spacing-20"></div>
</div>




<?php get_footer(); ?>