<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 * 
 */

function optionsframework_option_name() {

	// This gets the theme name from the stylesheet (lowercase and without spaces)
	$themename = get_theme_data(STYLESHEETPATH . '/style.css');
	$themename = $themename['Name'];
	$themename = preg_replace("/\W/", "", strtolower($themename) );
	
	$optionsframework_settings = get_option('optionsframework');
	$optionsframework_settings['id'] = $themename;
	update_option('optionsframework', $optionsframework_settings);
	
	// echo $themename;
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the "id" fields, make sure to use all lowercase and no spaces.
 *  
 */

function optionsframework_options() {
	
	// Test data
	$test_array = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five");
	
	// Multicheck Array
	$multicheck_array = array("one" => "French Toast", "two" => "Pancake", "three" => "Omelette", "four" => "Crepe", "five" => "Waffle");
	
	// Multicheck Defaults
	$multicheck_defaults = array("one" => "1","five" => "1");
	
	// Background Defaults
	
	$background_defaults = array('color' => '', 'image' => '', 'repeat' => 'repeat','position' => 'top center','attachment'=>'scroll');
	
		// If using image radio buttons, define a directory path
	$imagepath =  get_bloginfo('stylesheet_directory') . '/images/';
	$adminemail = get_bloginfo('admin_email');
	
	// Color Schemes
	$color_scheme = array(
"" => "Upload Own Background",
$imagepath."bg/1.jpg" => "Color Scheme 1",
$imagepath."bg/2.jpg" => "Color Scheme 2",
$imagepath."bg/3.jpg" => "Color Scheme 3",
$imagepath."bg/4.jpg" => "Color Scheme 4",
$imagepath."bg/5.jpg" => "Color Scheme 5",
$imagepath."bg/6.jpg" => "Color Scheme 6",
$imagepath."bg/7.jpg" => "Color Scheme 7",
$imagepath."bg/8.jpg" => "Color Scheme 8",
$imagepath."bg/9.jpg" => "Color Scheme 9",
$imagepath."bg/10.jpg" => "Color Scheme 10",
$imagepath."bg/11.jpg" => "Color Scheme 11",
$imagepath."bg/12.jpg" => "Color Scheme 12",
$imagepath."bg/13.jpg" => "Color Scheme 13",
$imagepath."bg/14.jpg" => "Color Scheme 14",
$imagepath."bg/15.jpg" => "Color Scheme 15",
$imagepath."bg/16.jpg" => "Color Scheme 16",
$imagepath."bg/17.jpg" => "Color Scheme 17",
$imagepath."bg/18.jpg" => "Color Scheme 18",
$imagepath."bg/19.jpg" => "Color Scheme 19",
$imagepath."bg/20.jpg" => "Color Scheme 20",
$imagepath."bg/21.jpg" => "Color Scheme 21",
$imagepath."bg/22.jpg" => "Color Scheme 22",
$imagepath."bg/pic1.jpg" => "Background Image 1",
$imagepath."bg/pic2.jpg" => "Background Image 2",
$imagepath."bg/pic3.jpg" => "Background Image 3",
$imagepath."bg/pic4.jpg" => "Background Image 4",
$imagepath."bg/pic5.jpg" => "Background Image 5",
$imagepath."bg/pic6.jpg" => "Background Image 6");

	$slider_ani = array(
"fade" => "Fade",
"slide" => "Slide");

$service_show = array(
"3" => "3",
"6" => "6");

$ficon = array(
"feature1.png" => "Icon 1",
"feature2.png" => "Icon 2",
"feature3.png" => "Icon 3",
"feature4.png" => "Icon 4",
"feature5.png" => "Icon 5",
"feature6.png" => "Icon 6",
"feature7.png" => "Icon 7",
"feature8.png" => "Icon 8",
"feature9.png" => "Icon 9",
"feature10.png" => "Icon 10",
"feature11.png" => "Icon 11",
"feature12.png" => "Icon 12",
"feature13.png" => "Icon 13",
"feature14.png" => "Icon 14",
"feature15.png" => "Icon 15",
"feature16.png" => "Icon 16",
"feature17.png" => "Icon 17",
"feature18.png" => "Icon 18",
"feature19.png" => "Icon 19",
"feature20.png" => "Icon 20",
);
	
	// Pull all the categories into an array
	$options_categories = array();  
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
    	$options_categories[$category->cat_ID] = $category->cat_name;
	}
	
	// Pull all the pages into an array
	$options_pages = array();  
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	$options_pages[''] = 'Select a page:';
	foreach ($options_pages_obj as $page) {
    	$options_pages[$page->ID] = $page->post_title;
	}
		
	$options = array();
	
	//Start Basic Settings
		
	$options[] = array( "name" => "Basic settings",
						"type" => "heading");
						
	$options[] = array( "name" => "Logo Image Upload",
						"desc" => "Upload you're own logo using this uploader",
						"std" => $imagepath."logo.png",
						"id" => "logo_upload",
						"type" => "upload");
						
	$options[] = array( "name" => "Footer Settings",
						"desc" => "Customize the footer description, you can edit this portion or leave it as it is.",
						"id" => "footerinfo",
						"std" => "Copyright &copy; Supportaa. All right reserved.",
						"type" => "text");			
						
	//End basic Settings

	
	
	
	//Start Home page Layout
	
	$options[] = array( "name" => "Home Layout",
						"type" => "heading");
						
	$options[] = array( "name" => "Home Page Layout Selector",
						"desc" => "Choose a layout for the homepage. Select a layout they click save.",
						"id" => "home_layout",
						"std" => "layout1",
						"type" => "images",
						"options" => array(
							'layout1' => $imagepath . 'layouts/layout1.png',
							'layout2' => $imagepath . 'layouts/layout2.png',
							'layout3' => $imagepath . 'layouts/layout3.png',
							'layout4' => $imagepath . 'layouts/layout4.png',));
	
	//End Home page Layout


	$options[] = array( "name" => "Homepage Settings",
						"type" => "heading");
						
						
	$options[] = array( "desc" => "Do you want to Enable <b>Homepage Content?</b>",
						"id"   => "enablehomecont",
						"std"  => "0",
						"type" => "checkbox");	
						
	$options[] = array( "name" => "Choose Which Page to be the home page Content",
						"desc" => 'Choose which <b>"Page"</b> you want to be displayed as a Home Content, it will be displayed at the home page.',
						"id" => "homecontent",
						"std" => "0",
						"type" => "select",
						"options" => $options_pages);
						
	$options[] = array( "desc" => "Do you want to show <b>Welcome Message on Homepage?</b>",
						"id"   => "enablewelcome",
						"std"  => "0",
						"type" => "checkbox");
						
	$options[] = array( "name" => "Welcome Message",
						"desc" => "Enter some catchy welcome message on homepage, Optional if you want to display or not.",
						"id"   => "welcome_msg",
						"std" => "Hey there! I'm Average Joe and I make awesome WordPress themes. This can be used to describe what you do, how you do it, and who you do it for.",
						"type" => "textarea"); 
						
	$options[] = array( "desc" => "Do you want to Enable <b>Homepage Blog?</b>",
						"id"   => "enableblog",
						"std"  => "0",
						"type" => "checkbox");
						
	$options[] = array( "name" => "Homepage Blog Short Message",
						"desc" => "Enter some catchy welcome message for homepage blog, Optional if you want to display or not.",
						"id"   => "homeblog_msg",
						"std" => "Hey there! I'm Average Joe and I make awesome WordPress themes. This can be used to describe what you do, how you do it, and who you do it for.",
						"type" => "textarea"); 	
						
	$options[] = array( "desc" => "Do you want to Enable <b>Homepage Portfolio?</b>",
						"id"   => "enableportfolio",
						"std"  => "0",
						"type" => "checkbox");		
						
	$options[] = array( "name" => "Homepage Portfolio Short Message",
						"desc" => "Enter some catchy welcome message for homepage blog, Optional if you want to display or not.",
						"id"   => "homeportfolio_msg",
						"std" => "Hey there! I'm Average Joe and I make awesome WordPress themes. This can be used to describe what you do, how you do it, and who you do it for.",
						"type" => "textarea"); 		
						
						// Featured Services
						
	$options[] = array( "name" => "Featured Services",
						"type" => "heading");
						
	$options[] = array( "name" => "Enable Featured Service on Homepage",
						"desc" => "Do you want to Enable Featured Service on home page?",
						"id"   => "check_featserv",
						"std"  => "0",
						"type" => "checkbox");
						
						
						
						
						
	$options[] = array( "name" => "Featured Service Title",
						"desc" => "Enter title for the Service Feature",
						"id" => "servicetitle1",
						"std" => "Featured Service 1",
						"type" => "text");
						
	$options[] = array( "name" => "Choose an Icon",
						"desc" => "Let's you Choose from 1 to 45 kinds of icons.",
						"id" => "featured_icon1",
						"std" => "1.png",
						"type" => "select",
						"options" => $ficon);
							
	$options[] = array( "name" => "Featured Service Description",
						"desc" => "Enter Description for the Service Feature",
						"id" => "servicedesc1",
						"std" => "Featured Service 1",
						"type" => "textarea"); 
						



	$options[] = array( "name" => "Featured Service Title",
						"desc" => "Enter title for the Service Feature",
						"id" => "servicetitle2",
						"std" => "Featured Service 2",
						"type" => "text");
						
	$options[] = array( "name" => "Choose an Icon",
						"desc" => "Let's you Choose from 1 to 45 kinds of icons.",
						"id" => "featured_icon2",
						"std" => "1.png",
						"type" => "select",
						"options" => $ficon);
							
	$options[] = array( "name" => "Featured Service Description",
						"desc" => "Enter Description for the Service Feature",
						"id" => "servicedesc2",
						"std" => "Featured Service 2",
						"type" => "textarea"); 
						
						
						
						
	$options[] = array( "name" => "Featured Service Title",
						"desc" => "Enter title for the Service Feature",
						"id" => "servicetitle3",
						"std" => "Featured Service 3",
						"type" => "text");
						
	$options[] = array( "name" => "Choose an Icon",
						"desc" => "Let's you Choose from 1 to 45 kinds of icons.",
						"id" => "featured_icon3",
						"std" => "1.png",
						"type" => "select",
						"options" => $ficon);
							
	$options[] = array( "name" => "Featured Service Description",
						"desc" => "Enter Description for the Service Feature",
						"id" => "servicedesc3",
						"std" => "Featured Service 3",
						"type" => "textarea"); 
						
						
						
	$options[] = array( "name" => "Featured Service Title",
						"desc" => "Enter title for the Service Feature",
						"id" => "servicetitle4",
						"std" => "Featured Service 4",
						"type" => "text");
						
	$options[] = array( "name" => "Choose an Icon",
						"desc" => "Let's you Choose from 1 to 45 kinds of icons.",
						"id" => "featured_icon4",
						"std" => "1.png",
						"type" => "select",
						"options" => $ficon);
							
	$options[] = array( "name" => "Featured Service Description",
						"desc" => "Enter Description for the Service Feature",
						"id" => "servicedesc4",
						"std" => "Featured Service 4",
						"type" => "textarea"); 




//Start Slider Settings						
						
	$options[] = array( "name" => "Slider Settings",
						"type" => "heading");
						
	$options[] = array( "name" => "Show Slder?",
						"desc" => "Do you want to Enable Slider on home page?",
						"id"   => "check_slider",
						"std"  => "0",
						"type" => "checkbox");
						
	$options[] = array( "name" => "Choose Which Category to be the home page's Featured Slider",
						"desc" => 'Choose which <b>"Category"</b> you want to be displayed as a featured Slider.',
						"id" => "slider",
						"std" => "1",
						"type" => "select",
						"options" => $options_categories);
						
	$options[] = array( "name" => "How many slides to show",
						"desc" => "Enter the Amount of slides to show on the sliders, Enter 0 if you want to display all",
						"id" => "show_times",
						"std" => "5",
						"class" => "mini",
						"type" => "text");
						
	$options[] = array( "name" => "Slider Animation",
						"desc" => 'Choose a slider animation currently there are only 2 options fade and slide.',
						"id" => "slider_animation",
						"std" => "slide",
						"type" => "radio",
						"options" => $slider_ani);
						
						
  	// Social Icons
						
	$options[] = array( "name" => "Social Icons",
						"type" => "heading");
		
	$options[] = array( "name" => "Enable Social Icons on footers?",
						"desc" => "Do you want to Enable this feature?",
						"id"   => "check_socials",
						"std"  => "0",
						"type" => "checkbox");
						
	$options[] = array( "name" => "Facebook Fanpage",
						"desc" => "Enter your facebook fanpage",
						"id" =>   "fb",
						"std" =>  "http://facebook.com",
						"type" => "text");	
						
	$options[] = array( "name" => "Twitter Account",
						"desc" => "Enter your Twitter account",
						"id" =>   "tweet",
						"std" =>  "http://twitter.com",
						"type" => "text");
						
	$options[] = array( "name" => "Youtube Channel",
						"desc" => "Enter your Youtube Channel",
						"id" =>   "youtube",
						"std" =>  "http://youtube.com",
						"type" => "text");
						
	$options[] = array( "name" => "Linkedin URL",
						"desc" => "Enter your Linkedin URL",
						"id" =>   "linked",
						"std" =>  "http://linkedin.com",
						"type" => "text");
				
//End Slider Settings
										
	return $options;
}