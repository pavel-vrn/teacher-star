<?php

include('functions_admin.php');

// Register Single Custom Menu
register_nav_menu( 'header_menu','Navigation Menu for Header' );


//Resize Tag Cloud - This Function will Overwrite the default tag cloud size
function resize_tag_cloud_filter($args = array()) {
                // Do changes on the lines below
                $args['smallest'] = 8;
                $args['largest']  = 8;
                $args['unit']     = 'pt';

                return $args;
        }

        add_filter('widget_tag_cloud_args', 'resize_tag_cloud_filter', 20);
		
		
		
		
		
		


/* Enable Post Thumbnail */
add_theme_support( 'post-thumbnails' );


/* Add Image Size */

add_image_size( 'index-recent', 200, 100, true ); // Resize Pictures for Homepage recent blog/portfolio 200 width by 100 Height.
add_image_size( 'blog-post', 575, 250, true ); // Resize Pictures for Blog posts 575 width by 250 Height.
add_image_size( 'slider', 960, 300, true ); // Resize Pictures for slider images 960 width by 400 Height.
add_image_size( 'portfolio', 585, 350, true ); // Resize Pictures for Portfolio images 960 width by 400 Height.







//Function to enable Shortcode on widget
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode', 11);
add_filter( 'widget_text', array( $wp_embed, 'run_shortcode' ), 8 );
add_filter( 'widget_text', array( $wp_embed, 'autoembed'), 8 );




// [bartag foo="foo-value"]
function bartag_func( $atts ) {
	extract( shortcode_atts( array(
		'icon' => '1',
	), $atts ) );

	return "<img src='".get_bloginfo('template_url')."/images/icons/feature{$icon}.png'>";
}
add_shortcode( 'features', 'bartag_func' );









if ( function_exists('register_sidebar') )
    register_sidebars(1,array(
	    'name' => 'Footer Widget',
        'before_widget' => '<div class="one-fourth">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	
if ( function_exists('register_sidebar') )
    register_sidebars(1,array(
	    'name' => 'Blog Widget',
        'before_widget' => '<div class="widget-box">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));

if ( function_exists('register_sidebar') )
    register_sidebars(1,array(
	    'name' => 'Contact Page Widget',
        'before_widget' => '<div class="widget-box">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));










/* Function to Limit words and Filter Tags or elements */

function content($num) {
$theContent = get_the_content();
$output = preg_replace('/<a[^>]+./','', $theContent);
$output = preg_replace('/<img[^>]+./','', $theContent);
$output = preg_replace( '/<blockquote>.*<\/blockquote>/', '', $output );
$output = preg_replace( '/<h1>.*<\/h1>/', '', $output );
$output = preg_replace( '/<h2>.*<\/h2>/', '', $output );
$output = preg_replace( '/<h3>.*<\/h3>/', '', $output );
$output = preg_replace( '/<h4>.*<\/h4>/', '', $output );
$output = preg_replace( '/<h5>.*<\/h5>/', '', $output );
$output = preg_replace( '/<h6>.*<\/h6>/', '', $output );
$output = preg_replace( '|\[(.+?)\](.+?\[/\\1\])?|s', '', $output );
//$output = preg_replace('/<img[^>]+./','', $theContent);
$limit = $num+1;
$content = explode(' ', $output, $limit);
array_pop($content);
$content = implode(" ",$content).".";
echo $content;
}





//Function for Paging/Pagination	
function pagination($pages = '', $range = 2)
{  
     $showitems = ($range * 2)+1;  

     global $paged;
     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   

     if(1 != $pages)
     {
         echo "<div class='pagination'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
         echo "</div>\n";
     }
}







/* Add Custom Posts */

add_action( 'init', 'create_post_type' );
function create_post_type() {

/* Slider Custom Posts */
	register_post_type( 'sliderposts', /* this can be seen at the URL as a parameter and a unique id for the custom post */
		array(
			'labels' => array(
				'name' => __( 'Sliders' ), /* The Label of the custom post */
				'singular_name' => __( 'Slider' ) /* The Label of the custom post */
			),
			'public' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => 'slider'), /* The slug of the custom post */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail','custom-fields' ) /* enable basic for text editing */
		)
	);


/* Portfolio Custom Posts */
	register_post_type( 'portfolio', /* this can be seen at the URL as a parameter and a unique id for the custom post */
		array(
			'labels' => array(
				'name' => __( 'Portfolio' ), /* The Label of the custom post */
				'singular_name' => __( "Portfolio's" ) /* The Label of the custom post */
			),
			'public' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => 'slider'), /* The slug of the custom post */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail','custom-fields' ) /* enable basic for text editing */
		)
	);
	
}




?>