<?php get_header(); ?>





<!-- Margin -->
<div class="margin-2">

<div class="spacing-40"></div>

<!-- Single full Page Container-->
	<div id="single-full">
		<form role="search" method="get" id="searchform" action="<?php echo get_bloginfo( 'url' ).'/'; ?> " >
<input type="submit" class="header-submit" />
<input type="text" name="s" class="header-search" onfocus="if( this.value == 'Search...' ) this.value = '';" 

                    onblur="if( this.value == '' ) this.value = 'Search...';" 

                    value="Search..." 
 />
</form>
	<h2 class="entry-header"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>

	<div class="spacing-20"></div>

		<div class="entry wide-entry">
		
						<?php 
						$my_postid = get_page( $page_id );//This is page id or post id
						$content_post = get_post($my_postid);
						$content = $content_post->post_content;
						$content = apply_filters('the_content', $content);
						//$content = str_replace(']]>', ']]>', $content);
						echo $content; 
						?>
		
		</div>
	
	</div>
<!-- Single full Page Container-->


<div class="clr"></div>
<div class="spacing-40"></div>
</div>




<?php get_footer(); ?>