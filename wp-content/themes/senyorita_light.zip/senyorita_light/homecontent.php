<!-- Home Page Content -->
<div class="margin-2">
<div class="separator"></div>

<div class="clr"></div>
<div class="spacing-40"></div>
<div class="entry homecontent">
<?php 
$page_id = of_get_option('homecontent');
$page_data = get_page( $page_id );
$content = apply_filters('the_content', $page_data->post_content);

echo $content;
?>
</div>

<div class="clr"></div>
<div class="spacing-20"></div>

</div>
<!-- Home Page Content -->