<!--Recent Portfolio-->
<div class="margin-2">
<div class="spacing-40"></div>
<div class="one-fourth index-recent">
<span>Latest Portfolio</span>
<p><?php echo of_get_option('homeportfolio_msg'); ?></p>
</div>


	<?php
	query_posts('post_type=portfolio&posts_per_page=3');
	while ( have_posts() ) : the_post();
	?>

	<div class="one-fourth index-recent">
	
	<?php if(has_post_thumbnail()) { ?>
	<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('index-recent',array('title' => "") ); ?></a>
	<?php }else{ ?>
	<img src="<?php bloginfo( 'template_directory' ); ?>/images/noimage.png" height="100" />
	<?php } ?>
	
	<h4><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h4>
	</div>


<?php endwhile; ?>

<div class="clr"></div>
<div class="spacing-10"></div>
</div>
<!--Recent Portfolio-->