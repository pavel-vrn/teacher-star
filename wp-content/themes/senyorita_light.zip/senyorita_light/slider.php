<!--Slider-->
<div id="slider">

<!-- start Coin Jquery Slider -->
        <div id='coin-slider'>
		
	<?php
	query_posts('post_type=sliderposts');
	while ( have_posts() ) : the_post();
	?>
	
<a href="<?php echo get_permalink(); ?>">
        <?php the_post_thumbnail('slider'); ?>
    </a>

	<?php endwhile; ?>

		</div>
        <!-- end Coin Slider -->
		
</div>	
<!--Slider-->