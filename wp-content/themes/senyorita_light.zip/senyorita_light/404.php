<?php /* Template Name: Blog Right Sidebar */ ?>
<?php get_header(); ?>


<!-- Page Header-->
<div class="margin-2" id="page-header">

<div id="page-header-con">
	<h2>Page Not Found</h2>
</div>

<form>
<input type="button" class="header-submit" />
<input type="text" name="s" class="header-search" onfocus="if( this.value == 'Search...' ) this.value = '';" 

                    onblur="if( this.value == '' ) this.value = 'Search...';" 

                    value="Search..." 
 />
</form>

<div class="clr"></div>
</div>
<!-- Page Header-->





<!-- Margin -->
<div class="margin-2">

<div class="spacing-40"></div>

<!-- Blog Container-->
	<div id="blog-container">
	
	<h3 class="entry-header">The Page or Post you are looking for could not be found.</h3>
    
	</div>
<!-- Blog Container-->


<!-- Margin -->
<div id="widget-container">
<?php
			if ( !function_exists('dynamic_sidebar')
      					|| !dynamic_sidebar(2) ) : 
     						endif;
							
	 		?>
</div>
<!-- Margin -->

<div class="clr"></div>
<div class="spacing-20"></div>
</div>




<?php get_footer(); ?>