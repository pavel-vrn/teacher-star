<div class="margin-2">
<?php

$x = of_get_option('check_slider');
$y = of_get_option('enablewelcome');
if($x == 1){
echo '<div class="spacing-40"></div>';
}else{
echo '<div class="spacing-20"></div>';
}

?>
</div>

<?php
$y = of_get_option('check_featserv');
if($y == 1){
include('features.php');
}else{
echo '<div class="margin-2"><div class="spacing-40"></div></div>';
}
?>



<?php
$x = of_get_option('enableblog');
if($x == 1){
include('recent-blog.php');
}
?>

<?php
$x = of_get_option('enableportfolio');
if($x == 1){
include('recent-portfolio.php');
}
?>



<?php
$x = of_get_option('enablehomecont');
if($x == 1){
include('homecontent.php');
}
?>