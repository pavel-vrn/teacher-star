<?php get_header(); ?>






<!-- Margin -->
<div class="margin-2">

<div class="spacing-40"></div>

<!-- Blog Container-->
	<div id="blog-container">
	

    <?php
	query_posts( $query_string .'&posts_per_page=10&order=DESC&cat=-'.$filter.'&paged='.$paged );
				while ( have_posts() ) : the_post();
	?>
	
	
		<div class="blog-one-col">
		
		<a href="<?php echo get_permalink(); ?>">
		<?php the_post_thumbnail('blog-post',array('title' => "") ); ?>
		</a>
		
		<h2><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>
		
			<?php include('meta-data.php'); ?>
		
			<p><?php content('30'); ?></p>
			
		</div>
		
		<?php endwhile; ?>
		
		<?php pagination(); ?>
	</div>
<!-- Blog Container-->


<!-- Margin -->
<div id="widget-container">
<?php
			if ( !function_exists('dynamic_sidebar')
      					|| !dynamic_sidebar(2) ) : 
     						endif;
							
	 		?>
</div>
<!-- Margin -->

<div class="clr"></div>
<div class="spacing-20"></div>
</div>




<?php get_footer(); ?>