<?php if (is_user_logged_in()) { ?> 
<ul id="login-nav">
		<li><a href="<?php echo wp_logout_url( get_permalink() ); ?>"><img src="<?php bloginfo( 'template_directory' ); ?>/images/log.png">Logout</a></li>
	</ul>
<?php }else{ ?>

<ul id="login-nav">
		<li><a href="<?php echo wp_login_url( get_permalink() ); ?>">Login</a></li>
		<?php wp_register(); ?>
	</ul>
	
<?php } ?>